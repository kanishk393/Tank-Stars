package com.mygdx.game;

public class Weapon implements Cloneable {

    private String n;

    private int dam;

    private float tun;

    public Weapon(String n, int dam) {
        this.n = n;
        this.dam = dam;
        
        this.tun = 0;
    }

    public String getn() {
        return n;
    }

    public int getdam() {
        return dam;
    }

   

    public float gettun() {
        return tun;
    }

    public void settun(float tun) {
        this.tun = tun;
    }

    public boolean iff() {
        return tun <= 0;
    }

    public void fire() {

        tun = 1 / 100;
    }

    public Weapon Clone() {
        try {
            return (Weapon) super.clone();
        } catch (CloneNotSupportedException e) {
            throw new AssertionError();
        }
    }


}