package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector3;

import java.awt.*;
import java.util.concurrent.TimeUnit;

import static java.lang.System.exit;

public class MenuState extends State {
    private Texture background;
    private Texture playBtn;
    int second_flag=0;
    String json;
    private Rectangle playBtnBounds;
    OrthographicCamera camera;
    Second second = new Second(manage);
    ResumeGame1 resumeGame1 = new ResumeGame1(manage);

    NewGame1 newGame1 = new NewGame1(manage);
    menu menu = new menu(manage);
    P1 p1 = new P1(manage);
    P2 p2 = new P2(manage);
    S1 s1 = new S1(manage);

    int third_flag=0;
    int fourth_flag=0;
    int fifth_flag=0;
    int sixth_flag=0;
    int seventh_flag=0;
    int edge=0;
    int c1=0;
    int c2=0;

    public MenuState(Manager manage) {
        super(manage);
        background = new Texture("Loading.png");
        playBtn = new Texture("Play.png");
        playBtnBounds = new Rectangle(450, -50, 360, 140);
        camera = new OrthographicCamera();
        camera.setToOrtho(false, 1280, 720);
    }

    @Override
    public void handleInput() {
//        if (Gdx.input.justTouched()) {
//            manage.set(new Second(manage));
//            dispose();
//            second_flag = 1;
//        }
//        if(Gdx.input.justTouched())
//        {
//            manage.set(new Second(manage));
//            dispose();
//            second_flag=1;
////            if(Gdx.input.justTouched()) {
////                manage.set(new Third(manage));
////                dispose();
////            }
//        }
//        if(Gdx.input.getTextInput())
//        {
//                manage.set(new Third(manage));
//                dispose();
//                third_flag=1;
//        }
        Gdx.input.setInputProcessor(new InputAdapter() {

//            @Override
//            public boolean keyDown(int keyCode) {
//
//                if (Gdx.input.justTouched()) {
//                    manage.set(new Second(manage));
//                    dispose();
//                    second_flag = 1;
//                }
//                if (second_flag == 1 && keyCode == Input.Keys.ENTER) {
//                    manage.set(new Third(manage));
//                    dispose();
//                    second_flag = 1;
//                }
//
//                return true;
//            }

            @Override
            public boolean touchDown(int screenX, int screenY, int pointer, int button) {
                if (second_flag==0&&third_flag==0&&fourth_flag==0&&fifth_flag==0&&sixth_flag==0&&seventh_flag==0&&Gdx.input.isTouched()) {
                    Vector3 touch = new Vector3(Gdx.input.getX(), Gdx.input.getY(), 0);
                    System.out.println(touch);
                    camera.unproject(touch);
                    if (playBtnBounds.contains(touch.x, touch.y)) {
                        manage.set(new Second(manage));
                        second_flag=1;
                    }
                }
                if(Gdx.input.isTouched()&&second_flag==1)
                {
                    Vector3 touch = new Vector3(Gdx.input.getX(),Gdx.input.getY(),0);
                    camera.unproject(touch);
                    if(second.getPlayBtnBounds().contains(touch.x,touch.y)&&third_flag==0&&fourth_flag==0&&fifth_flag==0&&sixth_flag==0&&seventh_flag==0)
                    {
                        manage.set(new NewGame1((manage)));
                        third_flag=1;
                        edge = 1;
                        System.out.println(edge);



                    }
                    if(second.getPlayBtnBounds2().contains(touch.x,touch.y)&&third_flag==0&&fourth_flag==0&&fifth_flag==0&&sixth_flag==0&&seventh_flag==0)
                    {
                        manage.set(new ResumeGame1((manage)));
                        third_flag=1;


                    }
                    if(second.getPlayBtnBounds3().contains(touch.x,touch.y)&&third_flag==0&&fourth_flag==0&&fifth_flag==0&&sixth_flag==0&&seventh_flag==0)
                    {
                        exit(0);
                        third_flag=1;


                    }
                    if(third_flag==1&&fourth_flag==0&&fifth_flag==0&&sixth_flag==0&&seventh_flag==0)
                    {
                        if(newGame1.getPlayBtnBounds().contains(touch.x,touch.y))
                        {
                            manage.set(new P1(manage));
                            fourth_flag = 1;


                        }
                        if(edge==0&&(resumeGame1.getPlayBtnBounds().contains(touch.x,touch.y) || resumeGame1.getPlayBtnBounds1().contains(touch.x,touch.y)))
                        {
                            save s = new save(manage);
//                            s.desave_game(S1.class,json);

                            manage.set(new S1(manage));
                            fourth_flag = 1;
                            fifth_flag=1;
                            sixth_flag=1;

                        }


                    }
                    if(third_flag==1&&fourth_flag==1&&fifth_flag==0&&sixth_flag==0&&seventh_flag==0)
                    {
                        if(p1.getPlayBtnBounds().contains(touch.x,touch.y))
                        {
                            manage.set(new P2(manage));
                            fifth_flag = 1;
                            c1=1;

                        }
                        if(p1.getPlayBtnBounds1().contains(touch.x,touch.y))
                        {
                            manage.set(new P2(manage));
                            fifth_flag=1;
                            c1=1;


                        }
                        if(p1.getPlayBtnBounds2().contains(touch.x,touch.y))
                        {
                            manage.set(new P2(manage));
                            fifth_flag=1;
                            c1=1;


                        }


                    }
                    if(third_flag==1&&fourth_flag==1&&fifth_flag==1&&sixth_flag==0&&seventh_flag==0) {
                        if(p2.getPlayBtnBounds3().contains(touch.x,touch.y))
                        {
                            manage.set(new S1(manage));
                            sixth_flag = 1;
                            c2=1;

                        }


                    }
                    if(third_flag==1&&fourth_flag==1&&fifth_flag==1&&sixth_flag==1&&seventh_flag==0) {

                        if(s1.getPlayBtnBounds().contains(touch.x,touch.y))
                        {
                            manage.set(new menu(manage));
                            seventh_flag = 1;

                        }
                    }
                    if(third_flag==1&&fourth_flag==1&&fifth_flag==1&&sixth_flag==1&&seventh_flag==1) {

                        if(menu.getPlayBtnBounds().contains(touch.x,touch.y))
                        {

                            third_flag=1;
                            fourth_flag=1;
                            fifth_flag=1;
                            sixth_flag=0;
                            seventh_flag=0;
                            S1 s1 = new S1(manage);
                            manage.set(s1);
                            save s = new save(manage);


                        }
                        if(menu.getPlayBtnBounds2().contains(touch.x,touch.y))
                        {
                            manage.set(new save(manage));
                            save s = new save(manage);
                            s.save_game(s1);
                            manage.set(new save(manage));




                        }
                        if(menu.getPlayBtnBounds3().contains(touch.x,touch.y))
                        {

                            exit(0);

                        }
                    }





//                    if(third_flag==1&&fourth_flag==1&&fifth_flag==1&&sixth_flag==0&&seventh_flag==0)
//                    {
//                        if(p2.getPlayBtnBounds().contains(touch.x,touch.y))
//                        {
//                            manage.set(new S1(manage));
//                            sixth_flag = 1;
//
//                        }
//                        if(p2.getPlayBtnBounds1().contains(touch.x,touch.y))
//                        {
//                            manage.set(new S1(manage));
//                            sixth_flag=1;
//
//
//                        }
//                        if(p2.getPlayBtnBounds2().contains(touch.x,touch.y))
//                        {
//                            manage.set(new S1(manage));
//                            sixth_flag=1;
//
//
//                        }


//                    }

                }

                return false;
            }

        });
    }

    
    @Override
    public void update(float dt) {
        handleInput();
    }
    @Override
    public void render(SpriteBatch sb) {
        sb.begin();
        sb.draw(background, 0, 0, MyGdxGame.WIDTH, MyGdxGame.HEIGHT);
        sb.draw(playBtn, playBtnBounds.x, playBtnBounds.y, playBtnBounds.width, playBtnBounds.height);
        sb.end();
    }

    @Override
    public void dispose() {
        background.dispose();
        playBtn.dispose();
    }
}
