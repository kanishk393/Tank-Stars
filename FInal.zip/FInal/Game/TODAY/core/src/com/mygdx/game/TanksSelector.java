package com.mygdx.game;

public class TanksSelector {
    public class tanksSelector {
        private tanksSelector instance;
        private Tanks selectedTanks;

        private tanksSelector() {
            // private constructor to prevent external instantiation
        }

        public tanksSelector getInstance() {
            if (instance == null) {
                instance = new tanksSelector();
            }
            return instance;
        }

        public void selectTanks(Tanks Tanks) {
            this.selectedTanks = Tanks;
        }

        public Tanks getSelectedTanks() {
            return selectedTanks;
        }
    }
}
