package com.mygdx.game;

import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

import java.awt.*;

public class menu extends State {
    private Texture sec;
    private Texture playBtn;

    private Rectangle playBtnBounds;
    private Texture playBtn2;
    private Rectangle playBtnBounds2;
    private Texture playBtn3;
    private Rectangle playBtnBounds3;
    OrthographicCamera camera;

    public Texture getPlayBtn() {
        return playBtn;
    }

    public Rectangle getPlayBtnBounds() {
        return playBtnBounds;
    }

    public Texture getPlayBtn2() {
        return playBtn2;
    }

    public Rectangle getPlayBtnBounds2() {
        return playBtnBounds2;
    }

    public Texture getPlayBtn3() {
        return playBtn3;
    }

    public Rectangle getPlayBtnBounds3() {
        return playBtnBounds3;
    }

    public menu(Manager manage) {
        super(manage);
        sec = new Texture("2.png");
        playBtn = new Texture("continue.png");
        playBtnBounds = new Rectangle(830, 560, 366, 140);
        playBtn2 = new Texture("savegame.png");
        playBtnBounds2 = new Rectangle(830, 360, 356, 140);
        playBtn3 = new Texture("menuexit.png");
        playBtnBounds3 = new Rectangle(830, 160, 360, 140);
        camera = new OrthographicCamera();
        camera.setToOrtho(false, 1280, 720);

    }

    @Override
    public void handleInput() {


    }

    @Override
    public void update(float dt) {

    }

    @Override
    public void render(SpriteBatch sb) {
        sb.begin();
        sb.draw(sec, 0, 0, MyGdxGame.WIDTH, MyGdxGame.HEIGHT);
        sb.draw(playBtn, playBtnBounds.x, playBtnBounds.y, playBtnBounds.width, playBtnBounds.height);
        sb.draw(playBtn2, playBtnBounds2.x, playBtnBounds2.y, playBtnBounds2.width, playBtnBounds2.height);
        sb.draw(playBtn3, playBtnBounds3.x, playBtnBounds3.y, playBtnBounds3.width, playBtnBounds3.height);
        sb.end();
    }

    @Override
    public void dispose() {

    }
}
