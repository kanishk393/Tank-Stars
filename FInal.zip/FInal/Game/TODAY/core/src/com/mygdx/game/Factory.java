package com.mygdx.game;
import java.util.*;
public class Factory implements Cloneable {

        public enum WT {
            A,
            B,
            C,
        }

        private Factory() {
        }

        private static final Map<WT, Weapon> weapons = new HashMap<>();
        static {
            weapons.put(WT.A, new Weapon("A", 50));
            weapons.put(WT.B, new Weapon("B", 20));
            weapons.put(WT.C, new Weapon("C", 100));
        }

        public static Weapon createWeapon(WT type) {
            return weapons.get(type).Clone();
        }

}
