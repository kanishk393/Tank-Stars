package com.mygdx.game;

import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

import java.awt.*;

public class P2 extends State {
    private Texture sec;
    private Texture background;
    private Texture playBtn;
    private Rectangle playBtnBounds;

    private Texture playBtn1;
    private Rectangle playBtnBounds1;

    private Texture playBtn2;
    private Rectangle playBtnBounds2;

    private Texture playBtn3;

    public Texture getPlayBtn3() {
        return playBtn3;
    }

    public void setPlayBtn3(Texture playBtn3) {
        this.playBtn3 = playBtn3;
    }

    public Rectangle getPlayBtnBounds3() {
        return playBtnBounds3;
    }

    public void setPlayBtnBounds3(Rectangle playBtnBounds3) {
        this.playBtnBounds3 = playBtnBounds3;
    }

    private Rectangle playBtnBounds3;
    OrthographicCamera camera;

    public Texture getPlayBtn1() {
        return playBtn1;
    }

    public void setPlayBtn1(Texture playBtn1) {
        this.playBtn1 = playBtn1;
    }

    public Rectangle getPlayBtnBounds1() {
        return playBtnBounds1;
    }

    public void setPlayBtnBounds1(Rectangle playBtnBounds1) {
        this.playBtnBounds1 = playBtnBounds1;
    }

    public Texture getPlayBtn2() {
        return playBtn2;
    }

    public void setPlayBtn2(Texture playBtn2) {
        this.playBtn2 = playBtn2;
    }


    public Rectangle getPlayBtnBounds2() {
        return playBtnBounds2;
    }

    public void setPlayBtnBounds2(Rectangle playBtnBounds2) {
        this.playBtnBounds2 = playBtnBounds2;
    }

    public Texture getBackground() {
        return background;
    }

    public Texture getPlayBtn() {
        return playBtn;
    }

    public Rectangle getPlayBtnBounds() {
        return playBtnBounds;
    }

    public P2(Manager manage) {
        super(manage);
        sec = new Texture("Ct2.png");
        playBtn = new Texture("Tank1.png");
        playBtnBounds = new Rectangle(70, 150, 285, 250);
        playBtn1 = new Texture("Tank2.png");
        playBtnBounds1 = new Rectangle(500, 170, 260, 200);
        playBtn2 = new Texture("Tank3.png");
        playBtnBounds2 = new Rectangle(930, 200, 260, 200);
        playBtn3 = new Texture("next.png");
        playBtnBounds3 = new Rectangle(500, 20, 260, 100);
        camera = new OrthographicCamera();
        camera.setToOrtho(false, 1280, 720);
    }

    @Override
    protected void handleInput() {

    }

    @Override
    public void update(float dt) {

    }

    @Override
    public void render(SpriteBatch sb) {
        sb.begin();
        sb.draw(sec, 0, 0, MyGdxGame.WIDTH, MyGdxGame.HEIGHT);
        sb.draw(playBtn, playBtnBounds.x, playBtnBounds.y, playBtnBounds.width, playBtnBounds.height);
        sb.draw(playBtn1, playBtnBounds1.x, playBtnBounds1.y, playBtnBounds1.width, playBtnBounds1.height);
        sb.draw(playBtn2, playBtnBounds2.x, playBtnBounds2.y, playBtnBounds2.width, playBtnBounds2.height);
        sb.draw(playBtn3, playBtnBounds3.x, playBtnBounds3.y, playBtnBounds3.width, playBtnBounds3.height);

        sb.end();

    }


    @Override
    public void dispose() {

    }
}

