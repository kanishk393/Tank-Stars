package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Tanks extends State {
    private Sprite sec;
    String name;
    float Speed = 500.0f;

    public Sprite getSec() {

        return sec;
    }

    public void setSec(Sprite sec) {
        this.sec = sec;
    }

    float TankX = 0;
    float TankY = 0;
    float TankvX;
    float TankvY;
    float fuel = 300;


    public Tanks(Manager manage,String name,float TankX, float TankY) {
        super(manage);
        this.name=name;
        sec = new Sprite(new Texture(name));
        this.TankX=TankX;
        this.TankY=TankY;

    }

    public void move_right()
    {
        TankvX += 5;
    }
    public void move_left()
    {
        TankvX -= 5;
    }
    public void update_fuel(){
        TankX += TankvX;
        TankY += TankvY;

//        fuel -= Math.sqrt(TankvX * TankvX + TankvY * TankvY );
    }
    public void update() {
        TankvX=0;
        TankvY=0;
    }

    public void function_WASD(){
        if (Gdx.input.isKeyPressed(Input.Keys.A)) {
            move_left();
        }
        if (Gdx.input.isKeyPressed(Input.Keys.D)) {
            move_right();
        }


        if (fuel > 0) {
            update_fuel();

        }

        update();

    }
    public void function_UP_DOWN(){
        if (Gdx.input.isKeyPressed(Input.Keys.RIGHT)) {
            TankvX += 5;
        }
        if (Gdx.input.isKeyPressed(Input.Keys.LEFT)) {
            TankvX -= 5;
        }
        if (fuel > 0) {
            update_fuel();

        }

        update();
    }

    public void setPosition(){
        sec.setPosition(TankX, TankY);
    }
    public Weapon weapon(Weapon weap){
        return weap;

    }


    @Override
    public void handleInput() {

    }

    @Override
    public void update(float dt) {

    }

    @Override
    public void render(SpriteBatch sb) {

    }

    @Override
    public void dispose() {

    }
}
