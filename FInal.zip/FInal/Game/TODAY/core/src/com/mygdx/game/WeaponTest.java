package com.mygdx.game;

import org.junit.Test;

import static org.junit.Assert.*;

public class WeaponTest {
    @Test
    public void testConstructor() {
        Weapon weapon = new Weapon("Cannon", 50);
        assertEquals("Cannon", weapon.getn());
        assertEquals(50, weapon.getdam());
        assertEquals(0, weapon.gettun(), 0.001f);
    }

    @Test
    public void testCanFire() {
        Weapon weapon = new Weapon("Cannon", 50);
        assertTrue(weapon.iff());
        weapon.settun(0.1f);
        assertFalse(weapon.iff());
    }

    @Test
    public void testFire() {
        Weapon weapon = new Weapon("Cannon", 50);
        weapon.fire();
        assertEquals(2f, weapon.gettun(), 0.001f);
    }

    @Test
    public void testClone() {
        Weapon weapon = new Weapon("Cannon", 50);
        Weapon clone = weapon.Clone();
        assertEquals(weapon.getn(), clone.getn());
        assertEquals(weapon.getdam(), clone.getdam());
        assertEquals(weapon.gettun(), clone.gettun(), 0.001f);
        assertFalse(weapon == clone);
    }
}
