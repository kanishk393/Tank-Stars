package com.mygdx.game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.utils.Json;
import com.badlogic.gdx.utils.JsonValue;

import java.awt.*;


public class S1 extends State implements Json.Serializable {
    private Texture sec;
    private Texture background;
    private Texture playBtn;
    private Rectangle playBtnBounds;

    private Texture playBtn1;
    private Rectangle playBtnBounds1;
    Rectangle T1bounds;
    Rectangle T2bounds;
    private Sprite carSprite;
    Sprite car2Sprite;
    OrthographicCamera camera;

    public Texture getBackground() {
        return background;
    }

    public Texture getPlayBtn() {
        return playBtn;
    }

    public Rectangle getPlayBtnBounds() {
        return playBtnBounds;
    }
    public Float x=0f;
    public Float y=0f;

    float fuel = 100;

    BitmapFont font;

    public Tanks T1;
    Tanks T2;

    public S1(Manager manage) {
        super(manage);
        camera = new OrthographicCamera();
        camera.setToOrtho(false, 1280, 720);
        sec = new Texture("gamebg.png");
        playBtn = new Texture("settings.png");
        playBtnBounds = new Rectangle(-15, 596, 260, 100);
        playBtn1 = new Texture("terrain.png");
        playBtnBounds1 = new Rectangle(0, 0, 1280, 190);
        T1 = new Tanks(manage,"GT1.png", playBtnBounds1.x+100, playBtnBounds1.y+playBtnBounds1.height-15);
        T1bounds = new Rectangle(100, 100, 100, 100);

        T2 = new Tanks(manage,"GT2.png", 1000, playBtnBounds1.y+playBtnBounds1.height-15);
        T2bounds = new Rectangle(200, 200, 100, 100);



        font = new BitmapFont();
        font.setColor(Color.BLACK);



    }

    @Override
    protected void handleInput() {

    }

    @Override
    public void update(float dt) {

    }

    @Override
    public void render(SpriteBatch sb) {
          SpriteBatch batch = new SpriteBatch();

        T1.function_WASD();
        T2.function_UP_DOWN();


        T1.setPosition();
        T2.setPosition();

        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        batch.begin();

        batch.draw(sec, 0, 0, MyGdxGame.WIDTH, MyGdxGame.HEIGHT);
        batch.draw(playBtn, playBtnBounds.x, playBtnBounds.y, playBtnBounds.width, playBtnBounds.height);
        batch.draw(playBtn1,playBtnBounds1.x, playBtnBounds1.y, playBtnBounds1.width, playBtnBounds1.height);

        T1.getSec().draw(batch);

        T2.getSec().draw(batch);

        font.draw(batch, "Fuel: " + (int)T1.fuel, 20, 20);
        font.draw(batch, "Fuel: " + (int)T2.fuel, 20, 40);

        batch.end();
        save s = new save(manage);



    }

    @Override
    public void dispose() {

    }

    @Override
    public void write(Json json) {
        json.writeValue("x", x);
        json.writeValue("y", y);
        json.writeValue("fuel", fuel);

    }

    @Override
    public void read(Json json, JsonValue jsonData) {
        x = json.readValue("x", float.class, jsonData);
        y = json.readValue("y", float.class, jsonData);
        fuel = json.readValue("fuel", float.class, jsonData);

    }



}

